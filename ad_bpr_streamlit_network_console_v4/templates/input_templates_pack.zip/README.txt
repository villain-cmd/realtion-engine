広告運用計算機 v3 入力テンプレート

01_performance: 楽天RPPの生レポートは変換せずアップロード可能です。
02_current_bid_setting: RMSの商品・キーワードCPC設定CSVの列構成です。
03_product_master: 粗利・販促費・商品名・カテゴリ等を付与する独自マスタです。
input_column_dictionary: 必須度・型・定義を一覧化しています。
